

require('dotenv').config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(express.json());
app.use(cors());

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "clave_super_secreta_petlink_2024"; 
const MONGO_URI = process.env.MONGO_URI;

mongoose.connect(MONGO_URI, { dbName: 'Petlink' })
  .then(() => console.log("✅ Conectado a MongoDB (Petlink)"))
  .catch((err) => console.error("❌ Error conectando a MongoDB:", err.message));



const rolSchema = new mongoose.Schema({
  nombre: { type: String, unique: true, required: true },
  descripcion: String,
  nivel: Number
});

const usuarioSchema = new mongoose.Schema({
  rol_id: { type: mongoose.Schema.Types.ObjectId, ref: "roles" },
  nombre: { type: String, required: true },
  numero_contacto: String,
  contrasena_: { type: String, required: true },
  correo: { type: String, unique: true, required: true },
  fecha_registro: { type: Date, default: Date.now },

  mascotas_asignadas: [{ type: mongoose.Schema.Types.ObjectId, ref: "mascotas" }]
});

usuarioSchema.pre("save", async function (next) {
  if (!this.isModified("contrasena_")) return next();
  try {
    const salt = await bcrypt.genSalt(10);
    this.contrasena_ = await bcrypt.hash(this.contrasena_, salt);
    next();
  } catch (err) {
    next(err);
  }
});

const mascotaSchema = new mongoose.Schema({
  usuario_id: { type: mongoose.Schema.Types.ObjectId, ref: "usuarios" }, 
  serial: { type: String, unique: true, required: true },
  nombre_mascota: String,
  raza_perro: String,
  edad_perro: Number,
});

const dispositivoSchema = new mongoose.Schema({
  mascota_id: { type: mongoose.Schema.Types.ObjectId, ref: "mascotas" },
  serial: { type: String, unique: true, required: true },
  estado: { type: String, default: "activo" },
  fecha_registro: { type: Date, default: Date.now }
});

const Rol = mongoose.model("roles", rolSchema);
const Usuario = mongoose.model("usuarios", usuarioSchema);
const Mascota = mongoose.model("mascotas", mascotaSchema);
const Dispositivo = mongoose.model("dispositivos", dispositivoSchema);

const verificarToken = (req, res, next) => {
  const token = req.header('Authorization') || req.header('x-token');
  if (!token) return res.status(401).json({ error: 'Acceso denegado. Falta token.' });

  try {
    const tokenLimpio = token.replace('Bearer ', '');
    const verificado = jwt.verify(tokenLimpio, JWT_SECRET);
    req.usuario = verificado;
    next();
  } catch (error) {
    res.status(400).json({ error: 'Token inválido o expirado' });
  }
};



app.post('/api/usuarios', async (req, res) => {
  try {
    const existeEmail = await Usuario.findOne({ correo: req.body.correo });
    if (existeEmail) return res.status(400).json({ error: 'El correo ya está registrado' });

    if (!req.body.rol_id) {
        const rolDueño = await Rol.findOne({ nombre: "dueño" });
        if (rolDueño) req.body.rol_id = rolDueño._id;
    }

    const usuario = new Usuario(req.body);
    const guardado = await usuario.save();
    
    const respuesta = guardado.toObject();
    delete respuesta.contrasena_;
    
    res.status(201).json(respuesta);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const usuario = await Usuario.findOne({ correo: req.body.correo }).populate('rol_id');
    if (!usuario) return res.status(400).json({ message: 'Usuario o contraseña incorrectos' });

    const validPass = await bcrypt.compare(req.body.contrasena_, usuario.contrasena_);
    if (!validPass) return res.status(400).json({ message: 'Usuario o contraseña incorrectos' });

    const token = jwt.sign(
      { _id: usuario._id, role: usuario.rol_id?.nombre },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    res.header('auth-token', token).json({
      message: 'Bienvenido',
      token: token,
      usuario: {
        nombre: usuario.nombre,
        correo: usuario.correo,
        rol: usuario.rol_id?.nombre,
        id: usuario._id
      }
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});



app.get('/api/mascotas/usuario/:userId', verificarToken, async (req, res) => {
  try {
    const { userId } = req.params;
    
    console.log('🔍 Buscando mascota para usuario:', userId);
    
    const mascota = await Mascota.findOne({ usuario_id: userId });
    
    if (!mascota) {
      return res.status(200).json({ 
        mensaje: 'No hay mascota registrada para este usuario',
        tieneMascota: false
      });
    }
    
    const dispositivo = await Dispositivo.findOne({ mascota_id: mascota._id });
    
    const respuesta = {
      tieneMascota: true,
      petInfo: {
        petName: mascota.nombre_mascota || 'Mi Mascota',
        petBreed: mascota.raza_perro || 'Sin especificar',
        petAge: mascota.edad_perro ? `${mascota.edad_perro} años` : 'Edad no registrada',
        petImageUrl: null,
        collarSerial: mascota.serial,
        stepsToday: Math.floor(Math.random() * 10000),
      },
      medicion: {
        id: 1,
        dispositivo_id: dispositivo?.serial || mascota.serial,
        fecha: new Date(),
        bateria: 85,
        ubicacion_lat: 4.60971,
        ubicacion_lng: -74.08175,
        estado_collar: dispositivo?.estado === 'activo',
        movimiento: false
      }
    };
    
    res.json(respuesta);
    
  } catch (err) {
    console.error('❌ Error al obtener mascota:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/mascotas/usuario/:userId', verificarToken, async (req, res) => {
  try {
    const { userId } = req.params;
    
    const usuario = await Usuario.findById(userId);
    if (!usuario) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    
    const mascotaExistente = await Mascota.findOne({ usuario_id: userId });
    if (mascotaExistente) {
      return res.status(400).json({ error: 'Este usuario ya tiene una mascota registrada' });
    }
    
    const serial = `PL-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    const nuevaMascota = new Mascota({
      usuario_id: userId,
      serial: serial,
      nombre_mascota: req.body.nombre_mascota || 'Mi Mascota',
      raza_perro: req.body.raza_perro || 'Sin especificar',
      edad_perro: req.body.edad_perro || 1
    });
    
    await nuevaMascota.save();
    
    const nuevoDispositivo = new Dispositivo({
      mascota_id: nuevaMascota._id,
      serial: serial,
      estado: 'activo'
    });
    
    await nuevoDispositivo.save();
    
    res.status(201).json({ 
      mensaje: 'Mascota creada exitosamente',
      mascota: nuevaMascota,
      dispositivo: nuevoDispositivo
    });
    
  } catch (err) {
    console.error('❌ Error al crear mascota:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/mascotas/disponibles', verificarToken, async (req, res) => {
  try {

    const mascotas = await Mascota.find()
      .populate('usuario_id', 'nombre correo numero_contacto')
      .lean();
    
 
    const mascotasFormateadas = mascotas.map(mascota => ({
      _id: mascota._id,
      nombre: mascota.nombre_mascota,
      raza: mascota.raza_perro,
      edad: mascota.edad_perro,
      serial: mascota.serial,
      dueno: {
        nombre: mascota.usuario_id?.nombre || 'Sin dueño',
        correo: mascota.usuario_id?.correo || 'N/A',
        telefono: mascota.usuario_id?.numero_contacto || 'N/A'
      }
    }));
    
    res.json(mascotasFormateadas);
    
  } catch (err) {
    console.error('❌ Error al obtener mascotas disponibles:', err);
    res.status(500).json({ error: err.message });
  }
});


app.get('/api/veterinario/:vetId/mascotas', verificarToken, async (req, res) => {
  try {
    const { vetId } = req.params;
    
    const veterinario = await Usuario.findById(vetId)
      .populate({
        path: 'mascotas_asignadas',
        populate: {
          path: 'usuario_id',
          select: 'nombre correo numero_contacto'
        }
      });
    
    if (!veterinario) {
      return res.status(404).json({ error: 'Veterinario no encontrado' });
    }

    const mascotasAsignadas = veterinario.mascotas_asignadas.map(mascota => ({
      _id: mascota._id,
      nombre: mascota.nombre_mascota,
      raza: mascota.raza_perro,
      edad: mascota.edad_perro,
      serial: mascota.serial,
      dueno: {
        nombre: mascota.usuario_id?.nombre || 'Sin dueño',
        correo: mascota.usuario_id?.correo || 'N/A',
        telefono: mascota.usuario_id?.numero_contacto || 'N/A'
      }
    }));
    
    res.json(mascotasAsignadas);
    
  } catch (err) {
    console.error('❌ Error al obtener mascotas del veterinario:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/veterinario/:vetId/vincular-mascotas', verificarToken, async (req, res) => {
  try {
    const { vetId } = req.params;
    const { mascotaIds } = req.body; 
    
    if (!Array.isArray(mascotaIds) || mascotaIds.length === 0) {
      return res.status(400).json({ error: 'Debes proporcionar al menos una mascota' });
    }
    
    const veterinario = await Usuario.findById(vetId).populate('rol_id');
    
    if (!veterinario) {
      return res.status(404).json({ error: 'Veterinario no encontrado' });
    }
    

    if (veterinario.rol_id?.nombre !== 'veterinario') {
      return res.status(403).json({ error: 'Solo los veterinarios pueden vincular mascotas' });
    }

    const mascotasActuales = veterinario.mascotas_asignadas.map(id => id.toString());
    const nuevasMascotas = mascotaIds.filter(id => !mascotasActuales.includes(id));
    
    veterinario.mascotas_asignadas.push(...nuevasMascotas);
    await veterinario.save();
    
    res.json({ 
      mensaje: 'Mascotas vinculadas exitosamente',
      total_mascotas: veterinario.mascotas_asignadas.length
    });
    
  } catch (err) {
    console.error(' Error al vincular mascotas:', err);
    res.status(500).json({ error: err.message });
  }
});


app.delete('/api/veterinario/:vetId/desvincular-mascota/:mascotaId', verificarToken, async (req, res) => {
  try {
    const { vetId, mascotaId } = req.params;
    
    const veterinario = await Usuario.findById(vetId);
    
    if (!veterinario) {
      return res.status(404).json({ error: 'Veterinario no encontrado' });
    }
    
    veterinario.mascotas_asignadas = veterinario.mascotas_asignadas.filter(
      id => id.toString() !== mascotaId
    );
    
    await veterinario.save();
    
    res.json({ 
      mensaje: 'Mascota desvinculada exitosamente',
      total_mascotas: veterinario.mascotas_asignadas.length
    });
    
  } catch (err) {
    console.error(' Error al desvincular mascota:', err);
    res.status(500).json({ error: err.message });
  }
});



function crearRutasCRUD(modelo, nombre, protegido = false) {
  const ruta = `/api/${nombre}`;

  app.get(ruta, async (req, res) => {
    try {
        const data = await modelo.find();
        res.json(data);
    } catch(err) { res.status(500).json({error: err.message}) }
  });

  if (nombre !== 'usuarios') {
    app.post(ruta, async (req, res) => {
        try {
            const nuevo = new modelo(req.body);
            await nuevo.save();
            res.status(201).json(nuevo);
        } catch (err) { res.status(400).json({ error: err.message }); }
    });
  }

  app.delete(`${ruta}/:id`, verificarToken, async (req, res) => {
    try {
      await modelo.findByIdAndDelete(req.params.id);
      res.json({ mensaje: `${nombre} eliminado correctamente` });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });
  
  app.put(`${ruta}/:id`, verificarToken, async (req, res) => {
      try {
          const actualizado = await modelo.findByIdAndUpdate(req.params.id, req.body, { new: true });
          res.json(actualizado);
      } catch (err) { res.status(400).json({ error: err.message }); }
  });
}

crearRutasCRUD(Usuario, "usuarios"); 
crearRutasCRUD(Mascota, "mascotas");
crearRutasCRUD(Dispositivo, "dispositivos");

app.get('/api/roles', async (req, res) => res.json(await Rol.find()));



async function inicializarRoles() {
  const rolesIniciales = [
    { nombre: "admin", descripcion: "Admin total", nivel: 4 },
    { nombre: "dueño", descripcion: "Dueño de mascotas", nivel: 3 },
    { nombre: "veterinario", descripcion: "Acceso médico", nivel: 2 },
    { nombre: "soporte", descripcion: "Soporte técnico", nivel: 1 }
  ];

  for (const rolData of rolesIniciales) {
    const existe = await Rol.findOne({ nombre: rolData.nombre });
    if (!existe) await new Rol(rolData).save();
  }
}

mongoose.connection.once("open", inicializarRoles);

app.listen(PORT, () => console.log(`⚙️ Servidor Petlink v7 corriendo en puerto ${PORT}`));